
### mini tool for cpu-info


$ minicpuinfo -h


#### Options

-h, --help      show this help menu
  -c, --cpu       shows how many cpu's available
  -d, --disk      disk partitions
  -D, --dpercent  disk percentage
  -m, --memusage  all memory usages
  -C, --cpuload   cpu load percentage


##### about me

-[sahayavalan](https://github.com/sahayavalan/)


...

...